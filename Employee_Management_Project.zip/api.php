<?php
header('Content-Type: application/json');
$mysqli = new mysqli("localhost", "root", "", "employee_db");
if ($mysqli->connect_error) {
    die(json_encode(["error" => $mysqli->connect_error]));
}

$action = $_GET['action'] ?? '';

if ($action == 'getEmployees') {
    $result = $mysqli->query("SELECT employees.id, employees.name, departments.department_name, positions.position_name FROM employees 
    INNER JOIN departments ON employees.department_id = departments.id 
    INNER JOIN positions ON employees.position_id = positions.id");
    $employees = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($employees);
} elseif ($action == 'addEmployee') {
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $mysqli->prepare("INSERT INTO employees (name, department_id, position_id) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $data['name'], $data['department_id'], $data['position_id']);
    $stmt->execute();
    echo json_encode(["success" => true]);
} elseif ($action == 'deleteEmployee') {
    $id = $_GET['id'] ?? 0;
    $mysqli->query("DELETE FROM employees WHERE id = $id");
    echo json_encode(["success" => true]);
}
?>
