$(document).ready(function() {
    $.getJSON("http://localhost:8000/api.php?action=getEmployees", function(data) {
        let rows = "";
        data.forEach(emp => {
            rows += `<tr>
                <td>${emp.id}</td>
                <td>${emp.name}</td>
                <td>${emp.department_name}</td>
                <td>${emp.position_name}</td>
                <td><button class="btn btn-danger btn-sm" onclick="deleteEmployee(${emp.id})">Delete</button></td>
            </tr>`;
        });
        $("#employeeTable").append(rows);
    });
});

function deleteEmployee(id) {
    $.get("http://localhost:8000/api.php?action=deleteEmployee&id=" + id, function() {
        location.reload();
    });
}
